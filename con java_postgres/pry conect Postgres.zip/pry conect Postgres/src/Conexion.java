import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class Conexion {
    Connection conn;

    public Conexion() {
        try {
            // Cargar el controlador JDBC de PostgreSQL
            Class.forName("org.postgresql.Driver");

            // URL de conexión a PostgreSQL
            String jdbcUrl = "jdbc:postgresql://172.18.0.2:5432/school?user=postgres&password=admin";
            this.conn = DriverManager.getConnection(jdbcUrl);
        } catch (Exception ex) {
            ex.printStackTrace();
            this.conn = null;
        }
    }

    public void closeConnection() {
        try {
            if (this.conn != null) {
                this.conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void listStudent() {
        try {
            // Preparar la consulta SQL
            PreparedStatement statement = this.conn.prepareStatement(
                    "SELECT * FROM student"
            );

            // Ejecutar la consulta y obtener los resultados
            ResultSet results = statement.executeQuery();
            while (results.next()) {
                System.out.println(results.getInt("nocontrol") + "\t" + results.getString("fullname"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
